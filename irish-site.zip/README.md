# Портфоліо · Данило Суржанський

Тристорінковий сайт (Про мене / Резюме / Аналітичний звіт) для публікації на **GitHub Pages**.

## Швидкий старт
1. Створи новий репозиторій на GitHub (наприклад, `danylo-surzhanskyi-portfolio`).
2. Завантаж вміст цієї папки до репозиторію (включно з папкою `assets/` та PDF).
3. Відкрий **Settings → Pages** і в розділі **Build and deployment** обери:  
   - **Source:** Deploy from a branch  
   - **Branch:** `main` /root
4. Збережи — через кілька хвилин сайт стане доступним за посиланням виду `https://<твій-username>.github.io/<назва-репозиторію>/`.

## Структура
```
/index.html      — Про мене
/resume.html     — Резюме (вбудований PDF)
/report.html     — Аналітичний звіт (Ірландія)
/styles.css      — стилі
/assets/My CV.pdf — файл резюме
```

© 2025 · created by Danylo Surzhanskyi
